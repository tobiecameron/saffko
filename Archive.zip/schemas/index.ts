import siteSettings from "./siteSettings"
import post from "./post"

export const schemaTypes = [siteSettings, post]
